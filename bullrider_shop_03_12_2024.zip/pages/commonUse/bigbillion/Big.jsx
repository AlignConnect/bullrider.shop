import React from 'react'
// import './big.css'

const Big = () => {
  return (
    <div className='grid sm:grid-cols-1 max-w-4xl mx-auto gap-2 py-5 bg-white'>

      <a href="https://bit.ly/3TNBq7n" className=" pop_imagehfv_big">
        <img src="https://imagedelivery.net/aacnHGAqlUDhaplA3bnkbA/24384f58-d945-4f3f-3670-ca59d0e3b400/public" alt="pic" className=" " loading='lazy' />
      </a>

      <a href=" https://amzn.to/3XLhpiY" className=" pop_imagehfv_big">
        <img src="https://imagedelivery.net/aacnHGAqlUDhaplA3bnkbA/2359c369-a8d5-471b-11e4-6a4ff4302b00/public" alt="pic" className="" loading='lazy' />
      </a>


    </div>
  )
}

export default Big
