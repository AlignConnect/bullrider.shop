import React from 'react'

const OrderNow = () => {
    return (
        <div>



            <div className={`text-center py-3 fontPoppins pop_imagehfv`} >
                <a className='decoration-0 text-white uppercase bg-gray-900 text-3xl font-bold px-10 py-2 rounded-full inline-block'>Order now</a>
            </div>


        </div>
    )
}

export default OrderNow