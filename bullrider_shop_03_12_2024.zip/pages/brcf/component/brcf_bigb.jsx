import React from 'react'

const brcf_bigb = () => {
    return (
        <div className='grid sm:grid-cols-1 max-w-4xl mx-auto gap-2 py-5 bg-white'>

            <a href="https://bit.ly/4eHp5tV" className=" pop_imagehfv_big">
                <img src="https://imagedelivery.net/aacnHGAqlUDhaplA3bnkbA/14e8afd7-e1aa-4c54-693c-444f6a088f00/public" alt="pic" className=" " loading='lazy' />
            </a>

            <a href="https://amzn.to/49VCQC0" className=" pop_imagehfv_big">
                <img src="https://imagedelivery.net/aacnHGAqlUDhaplA3bnkbA/2d0b27a7-109e-47ee-78e3-689017242800/public" alt="pic" className="" loading='lazy' />
            </a>


        </div>
    )
}

export default brcf_bigb